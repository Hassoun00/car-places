//
//  GNCustomHeaders.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@interface GNCustomHeaders : NSObject
+(NSDictionary*)getCustomHeaders;
-(NSURLRequest*)modifyRequest:(NSURLRequest*)request;
-(BOOL)shouldModifyRequest:(NSURLRequest *)request webview:(WKWebView *)webview;
@end
