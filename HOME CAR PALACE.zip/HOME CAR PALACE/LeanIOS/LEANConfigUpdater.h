//
//  LEANConfigUpdater.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANConfigUpdater : NSObject

+ (void)registerEvent:(NSString*)event data:(NSDictionary*)data;


@end
