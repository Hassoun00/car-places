//
//  LEANDlogDefinition.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#define DLog( s, ... ) NSLog( @"<%p %@:(%d)> %@", self, [[NSString stringWithUTF8String:__FILE__] lastPathComponent], __LINE__, [NSString stringWithFormat:(s), ##__VA_ARGS__] )
