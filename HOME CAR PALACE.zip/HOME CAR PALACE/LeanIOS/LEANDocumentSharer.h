//
//  LEANDocumentSharer.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANDocumentSharer : NSObject
+ (LEANDocumentSharer*)sharedSharer;
- (void)downloadImage:(NSURL*)url;
- (BOOL)isSharableRequest:(NSURLRequest*)req;
- (void)shareRequest:(NSURLRequest *)req fromButton:(UIBarButtonItem*) button;
- (void)shareUrl:(NSURL*)url fromView:(UIView*)view;
- (void)shareUrl:(NSURL*)url fromView:(UIView*)view filename:(NSString*)filename;
- (void)receivedRequest:(NSURLRequest*)request;
- (void)receivedResponse:(NSURLResponse*)response;
- (void)receivedWebviewResponse:(NSURLResponse*)response;
- (void)receivedData:(NSData*)data;
- (void)cancel;
- (void)finish;
@end
