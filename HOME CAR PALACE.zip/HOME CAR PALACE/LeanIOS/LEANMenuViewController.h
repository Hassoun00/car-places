//
//  LEANMenuViewController.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"
#import "LEANLoginManager.h"

@interface LEANMenuViewController : UITableViewController
- (void)updateMenuWithStatus:(NSString*)status;
- (void)parseProfilePickerJSON:(NSString*)json;
@end
