//
//  LEANNavigationController.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <UIKit/UIKit.h>
#import "REFrostedViewController.h"

@interface LEANNavigationController : UINavigationController
@property BOOL sidebarEnabled;
- (void)panGestureRecognized:(UIPanGestureRecognizer *)sender;
@end
