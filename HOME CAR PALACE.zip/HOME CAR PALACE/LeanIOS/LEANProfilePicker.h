//
//  LEANProfilePicker.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANProfilePicker : NSObject

@property NSMutableArray *names;
@property NSMutableArray *links;
@property NSInteger selectedIndex;

- (void)parseJson:(NSString*)json;
- (BOOL)hasProfiles;

@end
