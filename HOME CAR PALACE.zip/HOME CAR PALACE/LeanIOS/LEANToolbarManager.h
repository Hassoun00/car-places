//
//  LEANToolbarManager.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>
#import "LEANWebViewController.h"

@interface LEANToolbarManager : NSObject
- (instancetype)initWithToolbar:(UIToolbar*)toolbar webviewController:(LEANWebViewController*)wvc;
- (void)handleUrl:(NSURL *)url query:(NSDictionary*)query;
- (void)didLoadUrl:(NSURL*)url;
- (void)setToolbarEnabled:(BOOL)enabled;
@property NSString *urlMimeType;
@end
