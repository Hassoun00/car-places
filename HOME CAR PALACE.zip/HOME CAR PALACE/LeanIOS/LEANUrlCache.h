//
//  LEANUrlCache.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANUrlCache : NSObject
- (BOOL)hasCacheForRequest:(NSURLRequest*)request;
- (NSCachedURLResponse *)cachedResponseForRequest:(NSURLRequest *)request;
@end
