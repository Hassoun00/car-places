//
//  LEANUrlInspector.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANUrlInspector : NSObject

@property NSString *userId;

- (void)setup;
+ (LEANUrlInspector*)sharedInspector;
- (void)inspectUrl:(NSURL*)url;
@end
