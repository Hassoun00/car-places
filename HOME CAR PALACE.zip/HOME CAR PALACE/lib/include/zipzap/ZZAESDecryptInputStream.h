//
//  ZZAESDecryptInputStream.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

#import "ZZConstants.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZZAESDecryptInputStream : NSInputStream

- (nullable instancetype)initWithStream:(NSInputStream*)upstream
							   password:(NSString*)password
								 header:(uint8_t*)header
							   strength:(ZZAESEncryptionStrength)strength
								  error:(out NSError**)error;

- (void)open;
- (void)close;

- (NSStreamStatus)streamStatus;
- (NSError*)streamError;

- (NSInteger)read:(uint8_t*)buffer maxLength:(NSUInteger)len;
- (BOOL)getBuffer:(uint8_t* _Nullable* _Nonnull)buffer length:(NSUInteger*)len;
- (BOOL)hasBytesAvailable;

- (void)dealloc;

@end

NS_ASSUME_NONNULL_END
