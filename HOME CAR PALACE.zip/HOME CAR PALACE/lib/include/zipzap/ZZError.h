//
//  ZZError.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

/**
 * The domain of ZipZap errors.
 */
extern NSString* const ZZErrorDomain;

/**
 * The index of the erroneous entry.
 */
extern NSString* const ZZEntryIndexKey;

typedef NS_ENUM(NSInteger, ZZErrorCode)
{
	/**
	 * Cannot open an archive for reading.
	 */
	ZZOpenReadErrorCode,
	
	/**
	 * Cannot read the end of central directory.
	 */
	ZZEndOfCentralDirectoryReadErrorCode,
	
	/**
	 * Cannot read a central file header.
	 */
	ZZCentralFileHeaderReadErrorCode,
	
	/**
	 * Cannot read a local file.
	 */
	ZZLocalFileReadErrorCode,
	
	/**
	 * Cannot open an archive for writing.
	 */
	ZZOpenWriteErrorCode,
	
	/**
	 * Cannot write a local file.
	 */
	ZZLocalFileWriteErrorCode,
	
	/**
	 * Cannot write a central file header.
	 */
	ZZCentralFileHeaderWriteErrorCode,
	
	/**
	 * Cannot write the end of central directory.
	 */
	ZZEndOfCentralDirectoryWriteErrorCode,
    
	/**
	 * Cannot replace the zip file after writing.
	 */
	ZZReplaceWriteErrorCode,
	
	/**
	 * The compression used is currently unsupported.
	 */
	ZZUnsupportedCompressionMethod,
    
	/**
	 * The encryption used is currently unsupported.
	 */
	ZZUnsupportedEncryptionMethod,
    
	/**
	 * An invalid CRC checksum has been encountered.
	 */
	ZZInvalidCRChecksum,
    
	/**
	 * The wrong key was passed in.
	 */
	ZZWrongPassword,
	
	/**
	 * The data, stream or data consumer block failed but did not set the error.
	 * This will be set on the underlying error of the local file write.
	 */
	ZZBlockFailedWithoutError
};

static inline BOOL ZZRaiseErrorNo(NSError** error, ZZErrorCode errorCode, NSDictionary* userInfo)
{
	if (error)
		*error = [NSError errorWithDomain:ZZErrorDomain
									 code:errorCode
								 userInfo:userInfo];
	return NO;
}

static inline id ZZRaiseErrorNil(NSError** error, ZZErrorCode errorCode, NSDictionary* userInfo)
{
	if (error)
		*error = [NSError errorWithDomain:ZZErrorDomain
									 code:errorCode
								 userInfo:userInfo];
	return nil;
}

