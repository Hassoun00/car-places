//
//  ZipZap.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

#import "ZZArchive.h"
#import "ZZArchiveEntry.h"
#import "ZZConstants.h"
#import "ZZError.h"

//! Project version number for ZipZap.
FOUNDATION_EXPORT double ZipZapVersionNumber;

//! Project version string for ZipZap.
FOUNDATION_EXPORT const unsigned char ZipZapVersionString[];

