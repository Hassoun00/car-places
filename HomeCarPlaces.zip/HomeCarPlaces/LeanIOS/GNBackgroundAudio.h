//
//  GNBackgroundAudio.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GNBackgroundAudio : NSObject
- (void)handleUrl:(NSURL *)url query:(NSDictionary*)query;
- (void)start;
- (void)end;
@end

NS_ASSUME_NONNULL_END
