//
//  GNConfigPreferences.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface GNConfigPreferences : NSObject
+ (instancetype)sharedPreferences;

- (void)handleUrl:(NSURL *)url query:(NSDictionary*)query;
- (void)setInitialUrl:(NSString*)url;
- (NSString*)getInitialUrl;
@end
