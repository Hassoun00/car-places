//
//  GNJSBridgeInterface.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <WebKit/WebKit.h>
#import "LEANWebViewController.h"
#import "LEANRootViewController.h"

NS_ASSUME_NONNULL_BEGIN

static NSString * GNJSBridgeName = @"JSBridge";

@interface GNJSBridgeInterface : NSObject <WKScriptMessageHandler>
@end

NS_ASSUME_NONNULL_END
