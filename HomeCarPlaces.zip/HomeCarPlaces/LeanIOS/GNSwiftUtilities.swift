//
//  GNSwiftUtilities.swift
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

import UIKit

@objc
public class GNSwiftUtilities: NSObject {
    @objc class func deviceToken(data: Data) -> String {
        return data.map { String(format: "%02x", $0) }.joined()
    }
}
