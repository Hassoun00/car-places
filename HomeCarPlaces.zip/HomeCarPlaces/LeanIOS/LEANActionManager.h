//
//  LEANActionManager.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>
#import "LEANWebViewController.h"

@interface LEANActionManager : NSObject
@property NSMutableArray<UIBarButtonItem *> *items;
@property(readonly, assign) NSString *currentSearchTemplateUrl;

- (instancetype)initWithWebviewController:(LEANWebViewController*)wvc;
- (void)didLoadUrl:(NSURL*)url;
@end
