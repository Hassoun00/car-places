//
//  LEANAppDelegate.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <UIKit/UIKit.h>
#import "Reachability.h"
#import "GNRegistrationManager.h"
@import GoNativeCore;

@interface LEANAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) GNRegistrationManager *registration;
@property Reachability *internetReachability;
@property BOOL isFirstLaunch;
@property NSString *previousInitialUrl;
@property NSString *apnsToken;
@property (strong, nonatomic) GNBridge *bridge;

- (void)configureApplication;

@end
