//
//  LEANInstallation.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANInstallation : NSObject

+ (NSDictionary*)info;

@end
