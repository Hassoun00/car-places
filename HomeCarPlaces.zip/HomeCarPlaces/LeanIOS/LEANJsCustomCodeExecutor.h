//
//  LEANJsCustomCodeExecutor.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol CustomCodeHandler
- (NSDictionary*)execute:(NSDictionary*)params;
@end

@interface LEANJsCustomCodeExecutor : NSObject
+ (NSDictionary*)execute:(NSDictionary*)params;
+ (void)setHandler:(NSObject<CustomCodeHandler>*)customHandler;
@end

NS_ASSUME_NONNULL_END
