//
//  LEANRootViewController.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import "REFrostedViewController.h"
#import "LEANWebViewController.h"

@interface LEANRootViewController : REFrostedViewController

@property LEANWebViewController *webViewController;

// these are run on the top-most webview
- (void)loadUrl:(NSURL*)url;
- (void)loadUrlUsingJavascript:(NSURL *)url;
- (void)runJavascript:(NSString*)js;

- (BOOL)webviewOnTop;
- (void)setInitialUrl:(NSURL *)url; // for initial launch from push notification
- (void)presentAlert:(UIAlertController*)alert;
@end
