//
//  LEANTabManager.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>
#import "LEANWebViewController.h"

@interface LEANTabManager : NSObject
- (instancetype)initWithTabBar:(UITabBar*)tabBar webviewController:(LEANWebViewController*)wvc;
- (void)handleUrl:(NSURL *)url query:(NSDictionary*)query;
- (void)didLoadUrl:(NSURL*)url;
- (void)selectTabWithUrl:(NSString*)url javascript:(NSString*)javascript;
- (void)autoSelectTabForUrl:(NSURL*)url;
- (void)selectTabNumber:(NSUInteger)number;
- (void)deselectTabs;
- (void)setTabsWithJson:(NSDictionary*)json;
- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection;

@property BOOL javascriptTabs; // disables auto-loading of tabs from config
@end
