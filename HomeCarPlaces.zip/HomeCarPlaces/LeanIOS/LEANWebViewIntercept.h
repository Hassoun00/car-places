//
//  LEANWebViewIntercept.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface LEANWebViewIntercept : NSURLProtocol
+(void)register;
@end

@interface LEANWebviewInterceptTracker : NSObject
@property NSURLRequest *currentRequest;
+ (LEANWebviewInterceptTracker*)sharedTracker;
@end
