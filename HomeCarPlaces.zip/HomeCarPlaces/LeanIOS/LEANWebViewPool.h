//
//  LEANWebViewPool.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, LEANWebViewPoolDisownPolicy) {
    LEANWebViewPoolDisownPolicyAlways,
    LEANWebViewPoolDisownPolicyReload,
    LEANWebViewPoolDisownPolicyNever
};

static LEANWebViewPoolDisownPolicy kLEANWebViewPoolDisownPolicyDefault = LEANWebViewPoolDisownPolicyReload;

@interface LEANWebViewPool : NSObject
@property NSURLRequest *currentLoadingRequest;

+ (LEANWebViewPool*)sharedPool;

- (void)setup;
- (UIView*)webviewForUrl:(NSURL *)url policy:(LEANWebViewPoolDisownPolicy*)policy;
- (void)disownWebview:(UIView*)webview;
- (void)flushAll;

@end
