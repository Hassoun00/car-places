//
//  NSURL+LEANUtilities.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

@interface NSURL (LEANUtilities)

- (BOOL)matchesPathOf:(NSURL*)url2;
- (BOOL)matchesIgnoreAnchor:(NSURL*)url2;
@end
