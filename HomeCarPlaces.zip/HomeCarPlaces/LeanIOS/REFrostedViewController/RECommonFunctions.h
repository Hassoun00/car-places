//
// RECommonFunctions.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <Foundation/Foundation.h>

#ifndef REUIKitIsFlatMode
#define REUIKitIsFlatMode() REFrostedViewControllerUIKitIsFlatMode()
#endif

BOOL REFrostedViewControllerUIKitIsFlatMode(void);
