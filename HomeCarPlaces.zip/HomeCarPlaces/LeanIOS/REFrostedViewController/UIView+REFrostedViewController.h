//
// UIView+REFrostedViewController.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface UIView (REFrostedViewController)

- (UIImage *)re_screenshot;

@end
