//
//  ZZScopeGuard.h
//  HomeCarPlace
//
//  Created by hassoun on 04/06/2023.
//

class ZZScopeGuard
{
public:
	ZZScopeGuard(void(^exit)()): _exit(exit)
	{
	}
	
	~ZZScopeGuard()
	{
		_exit();
	}

private:
	void(^_exit)();
};
